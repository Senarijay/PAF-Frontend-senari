package com.electricity.paf.Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class Customer {

	private Connection connect() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

			// Provide the correct details: DBServer/DBName, username, password
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/electricity?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",
					"root", "SettaJay");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}

	public String insertCustomer(String cusName, String cusAddress, String cusNIC, String cusEmail, String cusPno) {
		String output = "";
		try {
			Connection con = connect();
			if (con == null) {
				return "Error while connecting to the database for inserting.";
			}
			// create a prepared statement
			String query = " insert into customermanage(`cusID`,`cusName`,`cusAddress`,`cusNIC`,`cusEmail`,`cusPno`)"
					+ " values (?, ?, ?, ?, ?, ?)";
			PreparedStatement preparedStmt = con.prepareStatement(query);
			// binding values
			preparedStmt.setInt(1, 0);
			preparedStmt.setString(2, cusName);
			preparedStmt.setString(3, cusAddress);
			preparedStmt.setString(4, cusNIC);
			preparedStmt.setString(5, cusEmail);
			preparedStmt.setString(6, cusPno);
			// execute the statement
			preparedStmt.execute();
			con.close();
			output = "Inserted successfully";
		} catch (Exception e) {
			output = "Error while inserting the customer.";
			System.err.println(e.getMessage());
		}
		return output;
	}

	public Response readCustomer() {
		JsonObject obj = new JsonObject();
		JsonArray jsArray = new JsonArray();
		obj.addProperty("state","1");
		
		try {
			Connection con = connect();
			if (con == null) {
				obj.add("data", jsArray);
				obj.addProperty("message", "Error while connecting to the database for reading.");
				
				Response  response = Response.status(Status.OK).entity(obj.toString()).header("Access-Control-Allow-Origin", "*")
						.header("Access-Control-Allow-Methods", "GET, POST, DELETE, PUT")
						.allow("OPTIONS").build();
				
				return response;
			}
			// Prepare the html table to be displayed
			
			String query = "select * from customermanage";
			Statement stmt = (Statement) con.createStatement();
			ResultSet rs = ((java.sql.Statement) stmt).executeQuery(query);
			// iterate through the rows in the result set
			while (rs.next()) {
				JsonObject objs = new JsonObject();
				String cusID = Integer.toString(rs.getInt("cusID"));
				String cusName = rs.getString("cusName");
				String cusAddress = rs.getString("cusAddress");
				String cusNIC = rs.getString("cusNIC");
				String cusEmail = rs.getString("cusEmail");
				String cusPno = rs.getString("cusPno");

				objs.addProperty("cusID",cusID );
				objs.addProperty("cusName",cusName );
				objs.addProperty("cusAddress", cusAddress);
				objs.addProperty("cusNIC", cusNIC);
				objs.addProperty("cusEmail", cusEmail);
				objs.addProperty("cusPno", cusPno);
				
				jsArray.add(objs);
				
			}
			con.close();
			// Complete the html table
			obj.add("data", jsArray);
			obj.addProperty("message", "Succesfully get all coustomer info !");
			
		} catch (Exception e) {
			//output = "Error while reading the customer.";
			obj.addProperty("message", e.getMessage());
			System.err.println(e.getMessage());
		}
		Response  response = Response.status(Status.OK).entity(obj.toString()).header("Access-Control-Allow-Origin", "*")
				.header("Access-Control-Allow-Methods", "GET, POST, DELETE, PUT")
				.allow("OPTIONS").build();
		
		return response;
	}

	public String updateCustomer(String cusID, String cusName, String cusAddress, String cusNIC, String cusEmail, String cusPno) {
		String output = "";

		try {
			Connection con = connect();

			if (con == null) {
				return "Error while connecting to the database for updating.";
			}

			// create a prepared statement
			String query = "UPDATE customermanage SET cusName=?,cusAddress=?,cusNIC=?,cusEmail=?,cusPno=?" + "WHERE cusID=?";

			PreparedStatement preparedStmt = con.prepareStatement(query);

			// binding values
			preparedStmt.setString(1, cusName);
			preparedStmt.setString(2, cusAddress);
			preparedStmt.setString(3, cusNIC);
			preparedStmt.setString(4, cusEmail);
			preparedStmt.setString(5, cusPno);
			preparedStmt.setInt(6, Integer.parseInt(cusID));

			// execute the statement
			preparedStmt.execute();
			con.close();

			output = "Updated successfully";
		} catch (Exception e) {
			output = "Error while updating the customer.";
			System.err.println(e.getMessage());
		}

		return output;
	}

	public String deleteCustomer(String cusID) {
		String output = "";

		try {
			Connection con = connect();

			if (con == null) {
				return "Error while connecting to the database for deleting.";
			}

			// create a prepared statement
			String query = "delete from customermanage where cusID=?";

			PreparedStatement preparedStmt = con.prepareStatement(query);

			// binding values
			preparedStmt.setInt(1, Integer.parseInt(cusID));

			// execute the statement
			preparedStmt.execute();
			con.close();

			output = "Deleted successfully";
		} catch (Exception e) {
			output = "Error while deleting the customer.";
			System.err.println(e.getMessage());
		}

		return output;
	}

}
