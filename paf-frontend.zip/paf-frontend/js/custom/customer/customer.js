$(function() {

    getBillsInfo();
    
    });

const addCustomer = (e) => {

    e.preventDefault();

    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Save it!'
    }).then((result) => {
        if (result.isConfirmed) {
            const cus_nam = $("#cus_nam").val();
            const cus_add = $("#cus_add").val();
            const cus_nic = $("#cus_nic").val();
            const cus_ema = $("#cus_ema").val();
            const contactnb = $("#contactnb").val();

            //add bill api

            $.ajax({
                type: "POST",
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                data: `cusName=+${encodeURIComponent(cus_nam)}`+`&cusAddress=+${encodeURIComponent(cus_add)}`+`&cusNIC=+${encodeURIComponent(cus_nic)}`+`&cusEmail=+${encodeURIComponent(cus_ema)}`+`&cusPno=+${encodeURIComponent(contactnb)}`,
                url: "http://localhost:8090/API/webapi/API/addCoustomer",
                success: function (data) {
                    console.log(data);
                    if (data) {
                        Swal.fire(
                            'Successful!',
                            'Customer Details Saved!',
                            'success'
                        );
                        clearForm();
                    } else {
                        Swal.fire(
                            'Error!',
                            'Unable to save!',
                            'error'
                        );
                    }


                }
            });
        }
    })
}

const updateCustomer = (e) => {

    e.preventDefault();

    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Save it!'
    }).then((result) => {
        if (result.isConfirmed) {
            const cus_nam = $("#cus_nam").val();
            const cus_add = $("#cus_add").val();
            const cus_nic = $("#cus_nic").val();
            const cus_ema = $("#cus_ema").val();
            const contactnb = $("#contactnb").val();


            //add bill api

            $.ajax({
                type: "POST",
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                data: $.param({cusID: cus_num,cusName: cus_nam, cusAddress : cus_add,cusNIC: cus_nic, cusEmail: cus_ema,cusPno:contactnb}),
                url: "http://localhost:8090/API/webapi/API/updateCoustomer",
                success: function (data) {
                    console.log(data);
                    if (data) {
                        Swal.fire(
                            'Successful!',
                            'Customer Details Saved!',
                            'success'
                        );
                        clearForm();
                        $("#addBtn").show();
                        $("updateBtn").hide();
                    } else {
                        Swal.fire(
                            'Error!',
                            'Unable to save!',
                            'error'
                        );
                    }


                }
            });
        }
    })
}

const getBillsInfo = () => {
    $.ajax({
		type: "GET",
		url: "http://localhost:8090/API/webapi/API/getAllCoustomerInfo",
		headers: {'Content-Type': 'application/x-www-form-urlencoded'},
		//data: $.param({username: $scope.userName, password: $scope.password}),
		success: function (data) {
			 
			$('#tblViewcustomermanage > tbody').html('');
            $.each(data.data, function (i, bill) {
				appenCustomerTable(bill);
			});
			
		}
	});
}

const appenCustomerTable = (item) => {
	
	let textToInsert = '';
	textToInsert += addRow(item);
	$('#tblViewcustomermanage > tbody').append(textToInsert);
};

const addRow = (item) => {
	
	const delete_btn = '<button type="button" class="btn btn-danger btn-xs" id="' + item.cusID + 'delete" onclick="removepayemnt(\'' + item.cusID + '\')"><span class="fas fa-trash-alt"></span>&nbsp;Delete Payement</button>';
	
    //pay_num,acc_num,cous_id,pay_date,payment
    const update_btn = '<button type="button" class="btn btn-waring btn-xs" id="' + item.cusID + 'delete" onclick="setUpdateData(\'' + item.cusID+'\',\''+item.cusName+ '\',\''+item.cusAddress+'\',\''+item.cusNIC+'\',\''+item.cusEmail+'\',\''+item.cusPno+'\')"><span class="fas fa-edit"></span>&nbsp;Edit Payement</button>';
	
//idpay_bill, cus_id, bill_no, month, tot_amount, status
	let row = '<tr id="' + item.cusID + '">'
        + '<td>' + item.cusID + '</td>'
		+ '<td>' + item.cusName + '</td>'
		+ '<td>' + item.cusAddress + '</td>'
		+ '<td>' + item.cusNIC + '</td>'
        + '<td>' + item.cusEmail + '</td>'
		+ '<td>' + item.cusPno + '</td>'
		+ '<td>'
			+ update_btn
		+ '</td>'
		+ '<td>'
			+ delete_btn
		+ '</td>'
		+ '</tr>';
	return row;
};


const setUpdateDate=(cus_num,cus_nam,cus_add,cus_nic,cus_ema,contactnb)=>{

    $("#cus_id").val(cus_num);
    $("#cus_nam").val(cus_nam);
    $("#cus_add").val(cus_add);
    $("#cus_nic").val(cus_nic);
    $("#cus_ema").val(cus_ema);
    $("#contactnb").val(contactnb);

    $("#addBtn").hide();
    $("updateBtn").show();
}

const removecustomer = (ids) => {

    // e.preventDefault();

    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Save it!'
    }).then((result) => {
        if (result.isConfirmed) {
            const cus_num = ids;

            //add bill api

            $.ajax({
                type: "POST",
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                data: `paymentData=+${encodeURIComponent(cus_num)}`,
                url: "http://localhost:8090/API/webapi/API/removeCoustomer",
                success: function (data) {
                    console.log(data);
                    if (data) {
                        Swal.fire(
                            'Successful!',
                            'Customer Details Removed!',
                            'success'
                        );
                        clearForm();
                        getBillsInfo();
                    } else {
                        Swal.fire(
                            'Error!',
                            'Unable to remove!',
                            'error'
                        );
                    }


                }
            });
        }
    })
}

